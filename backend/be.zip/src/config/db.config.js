// Không cần import dotenv nữa, đã được load ở env.config.js
export const PORT = process.env.PORT || 8000;
export const DB_HOST = process.env.DB_HOST || `localhost`;
export const DB_USER = process.env.DB_USER || 'root';
export const DB_PASS = process.env.DB_PASS || '';
export const DB_NAME = process.env.DB_NAME || 'beeit';
export const DB_PORT = process.env.DB_PORT || 3306;
