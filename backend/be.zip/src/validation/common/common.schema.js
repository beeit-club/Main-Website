// src/validations/common.schema.js
import * as yup from 'yup';

export const PaginationSchema = yup
  .object({
    page: yup
      .number()
      .optional()
      .nullable()
      .transform((value, originalValue) => {
        // Nếu không có giá trị hoặc undefined → trả về 1 (default)
        if (
          originalValue === undefined ||
          originalValue === null ||
          originalValue === ''
        ) {
          return 1;
        }
        const num = Number(originalValue);
        // Nếu không phải số hoặc nhỏ hơn 1 → trả về 1 (default)
        if (isNaN(num) || num < 1) return 1;
        return num;
      })
      .default(1),

    limit: yup
      .number()
      .optional()
      .nullable()
      .transform((value, originalValue) => {
        // Nếu không có giá trị hoặc undefined → trả về 10 (default)
        if (
          originalValue === undefined ||
          originalValue === null ||
          originalValue === ''
        ) {
          return 10;
        }
        const num = Number(originalValue);
        // Nếu không phải số hoặc nhỏ hơn 1 hoặc lớn hơn 100 → trả về 10 (default)
        if (isNaN(num) || num < 1 || num > 100) return 10;
        return num;
      })
      .default(10),
  })
  .default({ page: 1, limit: 10 });

export const params = {
  id: yup.object({
    id: yup
      .number()
      .typeError('Id phải là số')
      .integer('Id phải là số nguyên')
      .min(1, 'Id phải lớn hơn 1')
      .required('Thiếu id'),
  }),
  slug: yup.object({
    slug: yup
      .string()
      .required('Slug là bắt buộc')
      .matches(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, 'Slug không hợp lệ')
      .min(3, 'Slug phải có ít nhất 3 ký tự')
      .max(255, 'Slug không được vượt quá 255 ký tự'),
  }),
};
